<?php

return [
    'MAIN_DIRECTORY' => __DIR__."/../",
];