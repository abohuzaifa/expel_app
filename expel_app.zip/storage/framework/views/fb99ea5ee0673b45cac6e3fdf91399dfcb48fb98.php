



<?php $__env->startSection('content'); ?>
<style>
    .card {
        border: 1px solid #e3e6f0;
        border-radius: 10px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        margin-bottom: 2rem;
    }

    .card-header {
        background-color: #4e73df;
        color: white;
        padding: 1rem;
        border-bottom: 1px solid #e3e6f0;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }

    .card-header h3 {
        margin: 0;
    }

    .card-body {
        padding: 2rem;
    }

    .card-body h4 {
        margin-top: 1.5rem;
        margin-bottom: 1rem;
        color: #4e73df;
    }

    .card-body p {
        margin: 0.5rem 0;
    }

    .card-body p strong {
        display: inline-block;
        min-width: 150px;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 2rem;
    }
</style>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.request_view')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
<section class="section">
<div class="container">
    <div class="card">
        <div class="card-header">
            <h3><?php echo e(trans('lang.request_details')); ?></h3>
        </div>
        <div class="card-body">
            <h4><?php echo e(trans('lang.request_information')); ?></h4>
            <p><strong><?php echo e(trans('lang.id')); ?>:</strong> <?php echo e($request->id); ?></p>
            <p><strong><?php echo e(trans('lang.user_id')); ?>:</strong> <?php echo e($request->user_id); ?></p>
            <p><strong><?php echo e(trans('lang.from_date')); ?>:</strong> <?php echo e($request->from_date); ?></p>
            <p><strong><?php echo e(trans('lang.to_date')); ?>:</strong> <?php echo e($request->to_date); ?></p>
            <p><strong><?php echo e(trans('lang.parcel_address')); ?>:</strong> <?php echo e($request->parcel_address); ?></p>
            <p><strong><?php echo e(trans('lang.receiver_address')); ?>:</strong> <?php echo e($request->receiver_address); ?></p>
            <p><strong><?php echo e(trans('lang.receiver_mobile')); ?>:</strong> <?php echo e($request->receiver_mobile); ?></p>
            <p><strong><?php echo e(trans('lang.status')); ?>:</strong> <?php echo e(($request->status == 0 ? trans("lang.pending") : ($request->status == 1 || $request->status == 4 ? trans("lang.processing") : ($request->status == 2 ? trans("lang.cancel") : trans("lang.complete"))))); ?></p>
            <p><strong><?php echo e(trans('lang.payment_status')); ?>:</strong> <?php echo e($request->payment_status == 1 ? trans('lang.paid') : trans('lang.unpaid')); ?></p>
            <p><strong><?php echo e(trans('lang.amount')); ?>:</strong> $<?php echo e($request->amount); ?></p>
            
            <?php if($request->offer): ?>
            <h4><?php echo e(trans('lang.offer_information')); ?></h4>
            <p><strong><?php echo e(trans('lang.offer_id')); ?>:</strong> <?php echo e($request->offer->id); ?></p>
            <p><strong><?php echo e(trans('lang.offer_amount')); ?>:</strong> $<?php echo e($request->offer->amount); ?></p>
            <p><strong><?php echo e(trans('lang.driver_id')); ?>:</strong> <?php echo e($request->offer->user_id); ?></p>
            <p><strong><?php echo e(trans('lang.driver_name')); ?>:</strong> <?php echo e($request->offer->user->name); ?></p>
            <p><strong><?php echo e(trans('lang.driver_mobile')); ?>:</strong> <?php echo e($request->offer->user->mobile); ?></p>
            <p><strong><?php echo e(trans('lang.driver_license_no')); ?>:</strong> <?php echo e($request->offer->user->driving_license); ?></p>
            <p><strong><?php echo e(trans('lang.driver_vehicle_no')); ?>:</strong> <?php echo e($request->offer->user->number_plate); ?></p>
            <?php endif; ?>

            <?php if($request->user): ?>
            <h4><?php echo e(trans('lang.user_information')); ?></h4>
            <p><strong><?php echo e(trans('lang.name')); ?>:</strong> <?php echo e($request->user->name); ?></p>
            <p><strong><?php echo e(trans('lang.email')); ?>:</strong> <?php echo e($request->user->email); ?></p>
            <p><strong><?php echo e(trans('lang.mobile')); ?>:</strong> <?php echo e($request->user->mobile); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\expel_app\resources\views/request/show.blade.php ENDPATH**/ ?>