


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.user_list')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
            <a class="btn btn-success" href="<?php echo e(route('payment_method.create')); ?>"> <?php echo e(trans('lang.create_new')); ?></a>
       


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr>
   <th><?php echo e(trans('lang.number')); ?></th>
   <th><?php echo e(trans('lang.name')); ?></th>
   <th><?php echo e(trans('lang.slug')); ?></th>
   <th><?php echo e(trans('lang.status')); ?></th>
   <th width="280px"><?php echo e(trans('lang.action')); ?></th>
 </tr>
 <?php
 //echo "<pre>";print_r($perPage); exit;
 $page = $_GET['page'] ?? 1;
 $i = ($page*$perPage)-$perPage;
 ?>
 <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($payment->name); ?></td>
    <td><?php echo e($payment->slug); ?></td>
    <td>
       <?php if($payment->status == 0): ?>
       <a class="btn btn-warning text-center" href="<?php echo e(route('active',$payment->id)); ?>"><?php echo e(trans('lang.deactive')); ?></a>
       <?php else: ?>
       <a class="btn btn-success text-center" href="<?php echo e(route('inactive',$payment->id)); ?>"><?php echo e(trans('lang.active')); ?></a>
       <?php endif; ?>
    </td>
    
    <td>
       <a class="btn btn-primary" href="<?php echo e(route('payment_method.edit',$payment->id)); ?>"><?php echo e(trans('lang.edit')); ?></a>   
       <?php echo Form::open(['method' => 'DELETE','route' => ['payment_method.destroy', $payment->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit(trans('lang.delete'), ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?> 
    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php echo e($payments->onEachSide(1)->links('vendor.pagination.default')); ?>



        </div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/payment_method/index.blade.php ENDPATH**/ ?>