<?php //use App\Models\Offer; ?>



<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.shop_list')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr>
   <th><?php echo e(trans('lang.number')); ?></th>
   <th><?php echo e(trans('lang.from')); ?></th>
   <th><?php echo e(trans('lang.to')); ?></th>
   <th><?php echo e(trans('lang.user')); ?></th>
   <th><?php echo e(trans('lang.driver')); ?></th>
   <th><?php echo e(trans('lang.status')); ?></th>
   <th width="280px"><?php echo e(trans('lang.action')); ?></th>
 </tr>
 <?php
 //echo "<pre>";print_r($perPage); exit;
 $page = $_GET['page'] ?? 1;
 $i = ($page*$perPage)-$perPage;
 ?>
 
 <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php //echo"<pre>"; print_r($item); exit;?>
  <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($item->parcel_address); ?></td>
    <td><?php echo e($item->receiver_address); ?></td>
    <td><?php echo e($item->user->name); ?></td>
    <td><?php echo e(isset($item->offer->user->name ) ? $item->offer->user->name  : ""); ?></td>
    <td><?php echo e(($item->status == 0 ? trans("lang.pending") : ($item->status == 1 || $item->status == 4 ? trans("lang.processing") : ($item->status == 2 ? trans("lang.cancel") : trans("lang.complete"))))); ?></td>
    <td>
      <a class="btn btn-info" href="<?php echo e(route('request.show',$item->id)); ?>"><?php echo e(trans('lang.view')); ?></a>
      <a class="btn btn-primary" href="<?php echo e(route('request.edit',$item->id)); ?>"><?php echo e(trans('lang.tracking')); ?></a>
    </td>
    
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($requests->onEachSide(1)->links('vendor.pagination.default')); ?>





</div>
      </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\expel_app\resources\views/request/index.blade.php ENDPATH**/ ?>