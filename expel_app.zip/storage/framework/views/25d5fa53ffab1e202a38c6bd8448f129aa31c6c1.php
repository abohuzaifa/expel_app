


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1><?php echo e(trans('lang.create_user')); ?></h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
        <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
        <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
      </ol>
    </nav>
  </div>
<section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <a class="btn btn-primary" href="<?php echo e(route('payment_method.index')); ?>"> <?php echo e(trans('lang.back')); ?></a>
       


                        <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger">
                        <p class="msg"><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <div class="alert alert-danger d-none">
                        <p class="msg"></p>
                        </div>



<?php echo Form::model($payment, ['enctype'=>'multipart/form-data','method' => 'PATCH','route' => ['payment_method.update', $payment->id]]); ?>

<div class="row">

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="name"><?php echo e(trans('lang.name')); ?>:</label>
            <input type="text" name="name" class="form-control" required value="<?php echo e($payment->name); ?>">
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="slug"><?php echo e(trans('lang.slug')); ?>:</label>
            <select type="text" class="form-control" name="slug">
                <option <?php echo e($payment->slug == 'click_pay' ? "selected" : ""); ?> value="click_pay"><?php echo e(trans('lang.click_pay')); ?></option>
                <option <?php echo e($payment->slug == 'COD' ? "selected" : ""); ?> value="COD"><?php echo e(trans('lang.cod')); ?></option>
            </select>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="public_key"><?php echo e(trans('lang.public_key')); ?>:</label>
            <input type="text" class="form-control" name="public_key" value="<?php echo e($payment->public_key); ?>">
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="secret_key"><?php echo e(trans('lang.secret_key')); ?>:</label>
            <input type="text" class="form-control" name="secret_key" value="<?php echo e($payment->secret_key); ?>">
        </div><br>

  
    <div class="col-xs-12 col-sm-12 col-md-12 text-center"><br>
        <button type="submit" class="btn btn-primary"><?php echo e(trans('lang.submit')); ?></button>
    </div>
</div>
<?php echo Form::close(); ?>



        </div>
    </div>
</div>
</div>
    </section>

<?php $__env->stopSection(); ?>
<script>

  </script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/payment_method/edit.blade.php ENDPATH**/ ?>