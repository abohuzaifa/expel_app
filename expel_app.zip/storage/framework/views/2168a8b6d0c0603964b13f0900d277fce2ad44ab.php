


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.product_create')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
            
          <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
          </div>
          <?php endif; ?>



<?php echo Form::open(array('route' => 'product.store','method'=>'POST', 'enctype'=>'multipart/form-data')); ?>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 ">
        <div class="form-group">
            <strong><?php echo e(trans('lang.category')); ?>:</strong>
            <?php echo Form::select('category_id', $category,[], array('class' => 'form-control sel category', "required" =>"required")); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 shop">
        <div class="form-group">
            <strong><?php echo e(trans('lang.shop')); ?>:</strong>
            <?php echo Form::select('shop_id', $shop,[], array('class' => 'form-control sel shop', "required" =>"required")); ?>

        </div>
    </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="name"><?php echo e(trans('lang.name')); ?>:</label>
            <input type="text" name="name" class="form-control"value="<?php echo e(old('name')); ?>" required>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="image"><?php echo e(trans('lang.image')); ?>:</label>
            <input type="file" class="form-control" name="image[]" multiple>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12"> 
            <label for="description"><?php echo e(trans('lang.description')); ?>:</label>
            <textarea name="description" class="form-control"><?php echo e(old('description')); ?></textarea>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="price"><?php echo e(trans('lang.price')); ?>:</label>
            <input type="text" class="form-control" name="price" value="<?php echo e(old('price')); ?>" required>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="tax"><?php echo e(trans('lang.tax')); ?>:</label>
            <input type="text" class="form-control" name="tax" value="<?php echo e(old('tax')); ?>">
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="discount"><?php echo e(trans('lang.discount')); ?>:</label>
            <input type="text" class="form-control" name="discount" value="<?php echo e(old('discount')); ?>">
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="taxable"><?php echo e(trans('lang.taxable')); ?>:</label>
            <input type="checkbox"  name="taxable" value="<?php echo e(old('taxable')); ?>">
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="tax_inclusive"><?php echo e(trans('lang.tax_inclusive')); ?>:</label>
            <input type="checkbox"  name="tax_inclusive" value="<?php echo e(old('tax_inclusive')); ?>">
        </div>

  
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary"><?php echo e(trans('lang.submit')); ?></button>
    </div>
</div>
<?php echo Form::close(); ?>



</div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>
<script>
  $(document).ready(function() {
        // Assuming your <select> element has an id of 'mySelect'
        $('.category').select2();
        $('.shop').select2()
    });
</script>

<!-- ALTER TABLE `products` ADD `shop_id` INT NOT NULL DEFAULT '0' AFTER `category_id`; -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/product/create.blade.php ENDPATH**/ ?>