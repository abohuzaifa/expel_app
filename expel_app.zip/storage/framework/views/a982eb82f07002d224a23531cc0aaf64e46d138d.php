


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.banner_list')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.banner_list')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
          <a class="btn btn-success" href="<?php echo e(route('banners.create')); ?>"> <?php echo e(trans('lang.create_new_banner')); ?></a>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr>
   <th><?php echo e(trans('lang.number')); ?></th>
   <!-- <th>Name</th> -->
   <th><?php echo e(trans('lang.image')); ?></th>
   <th><?php echo e(trans('lang.status')); ?></th>
   <!-- <th>price</th> -->
   <th width="280px"><?php echo e(trans('lang.action')); ?></th>
 </tr>
 <?php
 //echo "<pre>";print_r($perPage); exit;
 $page = $_GET['page'] ?? 1;
 $i = ($page*$perPage)-$perPage;
 ?>
 <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e(++$i); ?></td>
    <!-- <td><?php echo e($item->p_name); ?></td> -->
    <td>
    <img src="<?php echo e(asset('images/'.$item->image)); ?>" style="width:100px;height:100px" alt="">
    </td>
    <td>
       <?php if($item->status == 0): ?>
       <a class="btn btn-warning text-center" href="<?php echo e(route('banner_active',$item->id)); ?>"><?php echo e(trans('lang.deactive')); ?></a>
       <?php else: ?>
       <a class="btn btn-success text-center" href="<?php echo e(route('banner_inactive',$item->id)); ?>"><?php echo e(trans('lang.active')); ?></a>
       <?php endif; ?></td>
       <td>
       <!-- <a class="btn btn-info" href="<?php echo e(route('product.show',$item->id)); ?>">Show</a> -->
       <a class="btn btn-primary" href="<?php echo e(route('banners.edit',$item->id)); ?>"><?php echo e(trans('lang.edit')); ?></a>
        <?php echo Form::open(['method' => 'DELETE','route' => ['banners.destroy', $item->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($banner->onEachSide(1)->links('vendor.pagination.default')); ?>




</div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/banners/index.blade.php ENDPATH**/ ?>