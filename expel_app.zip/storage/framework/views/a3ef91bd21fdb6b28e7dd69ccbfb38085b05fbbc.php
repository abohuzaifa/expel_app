


<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2><?php echo e(trans('lang.shop_edit')); ?></h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('shop.index')); ?>"> <?php echo e(trans('lang.back')); ?></a>
        </div>
    </div>
</div>


<?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
          </div>
          <?php endif; ?>


<?php echo Form::model($shop, ['enctype'=>'multipart/form-data','method' => 'PATCH','route' => ['shop.update', $shop->id]]); ?>

<div class="row">
                                <div class="col-12" >
                                    <label for="cat_ids" class="text-capitalize"><?php echo e(trans('lang.category')); ?></label>
                                    <select id="cat_ids" onchange="addPill();"
                                    class="svselect form-select form-select-sm">
                                      <option value="0"></option>
                                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div id="pillContainer" class="pill-container">
                                        <?php 
                                            $ids = explode(",",$shop->category_id);
                                            if(is_array($ids) && count($ids) > 0)
                                            {
                                                foreach($category as $cat)
                                                {
                                                    if(in_array($cat->id,$ids))
                                                    {
                                                        echo '<div class="pill" id="'.$cat->id.'-pill">
                                                                '.$cat->id.' - '.$cat->name.'
                                                                <a href="javascript:;">
                                                                <span style=" margin-left:30px; border:1px;" class="close-btn" onclick="removePill('.$cat->id.')">✖</span>
                                                                </a><input type="hidden" name="categories[]" value="'.$cat->id.'">
                                                            </div>';
                                                    }
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="name"><?php echo e(trans('lang.name')); ?>:</label>
            <input type="text" name="name" class="form-control"value="<?php echo e($shop->name); ?>" required>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="image"><?php echo e(trans('lang.image')); ?>:</label>
            <input type="file" class="form-control" name="image">
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12"> 
            <label for="description"><?php echo e(trans('lang.description')); ?>:</label>
            <textarea name="description" class="form-control"><?php echo e($shop->description); ?></textarea>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="reg_no"><?php echo e(trans('lang.registration_no')); ?>:</label>
            <input type="text" class="form-control" name="reg_no" value="<?php echo e($shop->reg_no); ?>" required>
        </div>

        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="address"><?php echo e(trans('lang.address')); ?>:</label>
            <input type="text" class="form-control" name="address" value="<?php echo e($shop->location); ?>">
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="latitude"><?php echo e(trans('lang.latitude')); ?>:</label>
            <input type="text" class="form-control" name="latitude" value="<?php echo e($shop->latitude); ?>" required>
        </div>
        <div  class="col-xs-12 col-sm-12 col-md-12">
            <label for="longitude"><?php echo e(trans('lang.longitude')); ?>:</label>
            <input type="text" class="form-control" name="longitude" value="<?php echo e($shop->longitude); ?>" required>
        </div>
  
    <div class="col-xs-12 col-sm-12 col-md-12 text-center"><br>
        <button type="submit" class="btn btn-primary"><?php echo e(trans('lang.submit')); ?></button>
    </div>
</div>
<?php echo Form::close(); ?>


        </div></section></div>
<?php $__env->stopSection(); ?>
<script>
    function addPill() {
      var selectField = document.getElementById('cat_ids');
      var selectedOption = selectField.options[selectField.selectedIndex];

      // Get text and value of the selected option
      var text = selectedOption.text;
      var selectedValue = selectedOption.value;
      if (selectedValue !== "") {
        var pillContainer = document.getElementById('pillContainer');

        // Check if the pill already exists
        if (!document.getElementById(selectedValue + '-pill') && selectedValue > 0) {
          var pill = document.createElement('div');
          pill.className = 'pill';
          pill.id = selectedValue + '-pill';
          pill.innerHTML = selectedValue+" - "+text + '<a href="javascript:;"><span style=" margin-left:30px; border:1px;" class="close-btn" onclick="removePill(\'' + selectedValue + '\')">&#10006;</span></a><input type="hidden" name="categories[]" value="'+selectedValue+'">';
          
          pillContainer.appendChild(pill);
        }

        // Reset the select field
        selectField.value = "";
      }
    }

    function removePill(value) {
      var pillToRemove = document.getElementById(value + '-pill');
      if (pillToRemove) {
        pillToRemove.remove();
      }
    }
  </script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/shop/edit.blade.php ENDPATH**/ ?>