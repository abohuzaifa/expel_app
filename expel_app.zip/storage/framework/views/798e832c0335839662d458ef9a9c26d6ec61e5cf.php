


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1><?php echo e(trans('lang.create_user')); ?></h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
        <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
        <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
      </ol>
    </nav>
  </div>
<section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <a class="btn btn-primary" href="<?php echo e(route('wallet.index')); ?>"> <?php echo e(trans('lang.back')); ?></a>
       


                        <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger">
                        <p class="msg"><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <div class="alert alert-danger d-none">
                        <p class="msg"></p>
                        </div>



<?php echo Form::model($wallet, ['enctype'=>'multipart/form-data','method' => 'PATCH','route' => ['wallet.update', $wallet->id]]); ?>

<div class="row">
    <div class="col-12">
        <div class="row">
            <div class="col-3" style="text-align: right;">
                <div class="form-group">
                    <input style="height: 15px; width:15px;" type="checkbox"  name="recharge" id="recharge" value="1" checked onchange="check_box1()">
                    <strong><?php echo e(trans('lang.recharge')); ?></strong>
                </div>
            </div>

            <div class="col-3" style="text-align: right;">
                <div class="form-group">
                    <input style="height: 15px; width:15px;" type="checkbox"  name="withdraw" id="withdraw" value="1" onchange="check_box2()">
                    <strong><?php echo e(trans('lang.withdraw')); ?></strong>
                </div>
            </div>

        </div>
    </div>
    <div class="row">
        <div class="col-8">
            <div class="form-group">
                <strong><?php echo e(trans('lang.amount')); ?>:</strong>
                <input type="number" id="amount" name="amount" class="form-control" value="0" required onkeyup="calculate();">
            </div>
        </div>
        <div class="col-4 d-none">
            <div class="form-group">
                <label for=""><?php echo e(trans('lang.wallet_amount')); ?></label>
                <input type="text" id="wallet_amount" readonly class="form-control" value="<?php echo e($wallet->amount); ?>">
            </div>
        </div>
    </div>
    

    <div class="col-xs-12 col-sm-12 col-md-12 text-center"><br>
        <button type="submit" class="btn btn-primary submit"><?php echo e(trans('lang.submit')); ?></button>
    </div>
</div>
<?php echo Form::close(); ?>



        </div>
    </div>
</div>
</div>
    </section>

<?php $__env->stopSection(); ?>
<script>
      function calculate()
      {
        var amount = $("#amount").val();
        var wallet_amount = $("#wallet_amount").val();
        if(amount > wallet_amount)
        {
            if ($("#withdraw").prop('checked')) {
                $('.msg').html('You cannot enter amount more then wallet amount.');
                $(".alert-danger").removeClass("d-none");
                $(".submit").attr("disabeld", "disabled");
                $("#amount").val(0);
            } else {
                $('.msg').html(``);
                $(".alert-danger").addClass("d-none");
                $(".submit").removeAttr("disabeld", "disabled");
            }
        } else {
            $('.msg').html(``);
            $(".alert-danger").addClass("d-none");
            $(".submit").removeAttr("disabeld", "disabled");
        }
        
      }
      function check_box1()
      {
        if ($("#recharge").prop('checked', true)) {
          $('#withdraw').not(this).prop('checked', false);
          $(".col-4").addClass('d-none');
          $("#amount").val(0);
        }
      }
      function check_box2()
      {
        if ($("#withdraw").prop('checked', true)) {
          $('#recharge').not(this).prop('checked', false);
          $(".col-4").removeClass('d-none');
          $("#amount").val(0);
        }
      }
     
    // });
  </script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/wallet/edit.blade.php ENDPATH**/ ?>