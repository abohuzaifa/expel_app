


<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2><?php echo e(trans('lang.category_edit')); ?></h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('category.index')); ?>"> <?php echo e(trans('lang.back')); ?></a>
        </div>
    </div>
</div>


<?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger">
            <p><?php echo e($message); ?></p>
          </div>
          <?php endif; ?>


<?php echo Form::model($category, ['enctype'=>'multipart/form-data','method' => 'PATCH','route' => ['category.update', $category->id]]); ?>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong><?php echo e(trans('lang.name')); ?>:</strong>
            <?php echo Form::text('name', null, array('placeholder' => trans('lang.name'),'class' => 'form-control')); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong><?php echo e(trans('lang.description')); ?>:</strong>
            <?php echo Form::textarea('description', null, array('placeholder' => trans('lang.description'),'class' => 'form-control')); ?>

        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong><?php echo e(trans('lang.image')); ?>:</strong>
           <input type="file" class="form-control" name="file" >
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center"><br>
        <button type="submit" class="btn btn-primary"><?php echo e(trans('lang.submit')); ?></button>
    </div>
</div>
<?php echo Form::close(); ?>


        </div></section></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/category/edit.blade.php ENDPATH**/ ?>