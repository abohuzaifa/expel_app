


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<!-- <head> -->
    <!-- <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
    <!-- <title>Order Detail</title> -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        main {
            max-width: 100%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        section {
            /* margin-bottom: 20px; */
            margin:30px;
        }

        h2 {
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #555;
        }
    </style>
<!-- </head> -->

<!-- <body> -->
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <header>
                <h1><?php echo e(trans('lang.order_detail')); ?></h1>
            </header>

            <main>
                <section>
                    <h2><?php echo e(trans('lang.order_summary')); ?></h2>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong><?php echo e(trans('lang.order_no')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->id); ?></p>
                            <p><strong><?php echo e(trans('lang.date_time')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(formatDateTimeToEnglish($order->created_at)); ?></p>
                            <p><strong><?php echo e(trans('lang.pickup_date_time')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->pickup_date_time != null ? formatDateTimeToEnglish($order->pickup_date_time) : trans('lang.nill')); ?></p>
                            <p><strong><?php echo e(trans('lang.status')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= ($order->order_status == 0 ? '<span class="badge bg-warning">'.trans('lang.pending').'</span>' : ($order->order_status == 1 ? '<span class="badge bg-success">'.trans('lang.complete').'</span>' : ($order->order_status == 2 ? '<span class="badge bg-primary">'.trans('lang.processing').'</span>' : '<span class="badge bg-danger">'.trans('lang.cancelled').'</span>'))) ?></p>
                            <p><strong><?php echo e(trans('lang.payment_method')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->payment->name); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong><?php echo e(trans('lang.tax')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->tax); ?></p>
                            <p><strong><?php echo e(trans('lang.discount')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->discount); ?></p>
                            <p><strong><?php echo e(trans('lang.due')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->due); ?></p>
                            <p><strong><?php echo e(trans('lang.paid')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->paid); ?></p>
                            <p><strong><?php echo e(trans('lang.total')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->total); ?></p>
                        </div>
                    </div>
                    
                </section>

                <section>
                    <h2><?php echo e(trans('lang.buyer_information')); ?></h2>
                    <p><strong><?php echo e(trans('lang.id')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->user->id); ?></p>
                    <p><strong><?php echo e(trans('lang.name')); ?>:</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->user->name); ?></p>
                    <p><strong><?php echo e(trans('lang.address')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->user->street_address); ?></p>
                    <p><strong><?php echo e(trans('lang.phone')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->user->mobile); ?></p>
                    <p><strong><?php echo e(trans('lang.email')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->user->email); ?></p>
                </section>

                <section>
                    <h2><?php echo e(trans('lang.seller_information')); ?></h2>
                    <p><strong><?php echo e(trans('lang.id')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->seller->id); ?></p>
                    <p><strong><?php echo e(trans('lang.name')); ?>:</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->seller->name); ?></p>
                    <p><strong><?php echo e(trans('lang.address')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->seller->street_address); ?></p>
                    <p><strong><?php echo e(trans('lang.phone')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->seller->mobile); ?></p>
                    <p><strong><?php echo e(trans('lang.email')); ?>:</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($order->seller->email); ?></p>
                </section>

                <section>
                    <h2><?php echo e(trans('lang.order_items')); ?></h2>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(trans('lang.product')); ?></th>
                                <th><?php echo e(trans('lang.price')); ?></th>
                                <th><?php echo e(trans('lang.quantity')); ?></th>
                                <th>tax</th>
                                <th><?php echo e(trans('lang.discount')); ?></th>
                                <th><?php echo e(trans('lang.net_total')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($order->orderItems as $key => $row) {
                                echo '
                                <tr>
                                    <td>'.($key+1).'</td>
                                    <td>'.$row->product->p_name.'</td>
                                    <td>'.$row->product->price.'</td>
                                    <td>'.$row->item_quantity.'</td>
                                    <td>'.$row->item_tax.'</td>
                                    <td>'.$row->item_discount.'</td>
                                    <td>'.$row->item_total.'</td>
                                </tr>
                                ';
                            } ?>
                            
                        </tbody>
                    </table>
                </section>

                <!-- <button>Contact Customer Support</button> -->
            </main>
        </div>
    </section>
</div>
<!-- </body>

</html> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/orders/show.blade.php ENDPATH**/ ?>