<!-- resources/views/vendor/pagination/default.blade.php -->

<?php if($paginator->hasPages()): ?>
    <ul class="pagination" style="font-size: 18px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>" style="margin-right: 10px;">
                <span aria-hidden="true"><?php echo e(trans('lang.prev')); ?></span>
            </li>
        <?php else: ?>
            <li style="margin-right: 10px;">
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><?php echo e(trans('lang.prev')); ?></a>
            </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <li class="disabled" aria-disabled="true" style="margin: 0 10px;"><span><?php echo e($element); ?></span></li>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($paginator->currentPage() == $page): ?>
                        <li class="active" aria-current="page" style="margin: 0 10px;"><span><?php echo e($page); ?></span></li>
                    <?php else: ?>
                        <li style="margin: 0 10px;"><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li style="margin-left: 10px;">
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><?php echo e(trans('lang.next')); ?></a>
            </li>
        <?php else: ?>
            <li class="disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>" style="margin-left: 10px;">
                <span aria-hidden="true"><?php echo e(trans('lang.prev')); ?></span>
            </li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/vendor/pagination/default.blade.php ENDPATH**/ ?>