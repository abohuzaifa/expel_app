 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

  <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
      <a class="nav-link " href="<?php echo e(route('home')); ?>">
        <i class="bi bi-grid"></i>
        <span><?php echo e(trans('lang.dashboard')); ?></span>
      </a>
    </li><!-- End Dashboard Nav -->

    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#Category" data-bs-toggle="collapse" href="#">
        <i class="bi bi-sliders"></i><span><?php echo e(trans('lang.category')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="Category" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="<?php echo e(route('category.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.category_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('category.create')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.category_create')); ?></span>
          </a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#shop" data-bs-toggle="collapse" href="#">
        <i class="bi bi-sliders"></i><span><?php echo e(trans('lang.shop')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="shop" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="<?php echo e(route('shop.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.shop_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('shop.create')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.shop_create')); ?></span>
          </a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#Item" data-bs-toggle="collapse" href="#">
        <i class="bi bi-sliders"></i><span><?php echo e(trans('lang.product')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="Item" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="<?php echo e(route('product.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.product_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('product.create')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.product_create')); ?></span>
          </a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#sellers" data-bs-toggle="collapse" href="#">
        <i class="bi bi-sliders"></i><span><?php echo e(trans('lang.users')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="sellers" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="<?php echo e(route('users.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.user_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('users.create')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.user_create')); ?></span>
          </a>
        </li>
      </ul>
    </li>





    <li class="nav-item">
      <a class="nav-link collapsed" data-bs-target="#setting-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-sliders"></i><span><?php echo e(trans('lang.setting')); ?></span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="setting-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
          <a href="<?php echo e(route('wallet.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.wallet_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('banners.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.banner_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('orders.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.order_list')); ?></span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('payment_method.index')); ?>">
            <i class="bi bi-circle"></i><span><?php echo e(trans('lang.payment_method')); ?></span>
          </a>
        </li>
      </ul>
    </li>
    <li class="nav-item">
      <a class="nav-link collapsed" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
      document.getElementById('logout-form').submit();">
        <i class="bi bi-box-arrow-in-right"></i>
        <?php echo e(trans('lang.logout')); ?>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
         <?php echo csrf_field(); ?>
        </form>
      </a>
    </li>






















    <!-- End Components Nav -->

    
    <!-- End Forms Nav -->

    
    <!-- End Tables Nav -->

    
    <!-- End Charts Nav -->

    <!-- End Icons Nav -->

    

  </ul>

</aside><!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/layouts/penal/main_manue.blade.php ENDPATH**/ ?>