


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.user_list')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
            <!-- <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> <?php echo e(trans('lang.create_new_user')); ?></a> -->
       


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr>
   <th><?php echo e(trans('lang.number')); ?></th>
   <th><?php echo e(trans('lang.name')); ?></th>
   <th><?php echo e(trans('lang.wallet_amount')); ?></th>
   <th><?php echo e(trans('lang.user_type')); ?></th>
   <th><?php echo e(trans('lang.status')); ?></th>
   <th width="280px"><?php echo e(trans('lang.action')); ?></th>
 </tr>
 <?php
 //echo "<pre>";print_r($perPage); exit;
 $page = $_GET['page'] ?? 1;
 $i = ($page*$perPage)-$perPage;
 ?>
 <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
    $user = DB::table('users')->where('id', $wallet->user_id)->get()[0];
 ?>
  <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($wallet->amount); ?></td>
    <td><?php echo e($user->user_type == 0 ? "ADMIN" : ($user->user_type == 1? "SELLER" : "BUYER")); ?></td>
    <td>
       <?php if($user->status == 0): ?>
       <a class="btn btn-warning text-center" ><?php echo e(trans('lang.deactive')); ?></a>
       <?php else: ?>
       <a class="btn btn-success text-center" ><?php echo e(trans('lang.active')); ?></a>
       <?php endif; ?></td>
    <td>
       <!-- <a class="btn btn-info" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a> -->
       <!-- <a class="btn btn-primary" href="<?php echo e(route('wallet.edit',$wallet->id)); ?>"><?php echo e(trans('lang.recharge')); ?></a> -->
       <a class="btn btn-primary" href="<?php echo e(route('wallet.edit',$wallet->id)); ?>"><?php echo e(trans('lang.update_wallet')); ?></a>
        
    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php echo e($wallets->onEachSide(1)->links('vendor.pagination.default')); ?>



        </div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/wallet/index.blade.php ENDPATH**/ ?>