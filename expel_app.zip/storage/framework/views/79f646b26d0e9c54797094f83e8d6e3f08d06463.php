


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans('lang.category_list')); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans('lang.home')); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans('lang.forms')); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans('lang.elements')); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr>
   <th><?php echo e(trans('lang.number')); ?></th>
   <th><?php echo e(trans('lang.name')); ?></th>
   <th><?php echo e(trans('lang.image')); ?></th>
   <th width="280px"><?php echo e(trans('lang.action')); ?></th>
 </tr>
 <?php
 $i =1;
 ?>
 
 <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e(++$i); ?></td>
    <td><?php echo e($item->name); ?></td>
    <td>
      <img src="<?php echo e(asset('uploads').'/'.$item->image); ?>" style="width:100px;height:100px" alt="">
    </td>

    <td>
       <!-- <a class="btn btn-info" href="<?php echo e(route('category.show',$item->id)); ?>">Show</a> -->
       <a class="btn btn-primary" href="<?php echo e(route('category.edit',$item->id)); ?>"><?php echo e(trans('lang.edit')); ?></a>
       <a class="<?= $item->admin_choice == 1 ? "btn btn-success": 'btn btn-warning'?>" href="<?php echo e(route('category.edit',[$item->id, "choice" => $item->admin_choice, "id" => $item->id])); ?>"><?php echo e(trans('lang.like')); ?></a>
        <?php echo Form::open(['method' => 'DELETE','route' => ['category.destroy', $item->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit(trans('lang.delete'), ['class' => 'btn btn-danger']); ?>

        <?php echo Form::close(); ?>

    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>




</div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\expel_app\resources\views/category/index.blade.php ENDPATH**/ ?>