


<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  <h1><?php echo e(trans("lang.user_list")); ?></h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html"><?php echo e(trans("lang.home")); ?></a></li>
      <li class="breadcrumb-item"><?php echo e(trans("lang.forms")); ?></li>
      <li class="breadcrumb-item active"><?php echo e(trans("lang.elements")); ?></li>
    </ol>
  </nav>
</div>
  <section class="section">
<div class="row">
<div class="col-lg-12">
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"></h5>




<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-bordered">
 <tr class="text-center">
   <th><?php echo e(trans("lang.number")); ?></th>
   <th><?php echo e(trans("lang.name")); ?></th>
   <th><?php echo e(trans("lang.email")); ?></th>
   <th><?php echo e(trans("lang.mobile")); ?></th>
   <th width="280px"><?php echo e(trans("lang.action")); ?></th>
 </tr>
 <?php
 //echo "<pre>";print_r($perPage); exit;
 $page = $_GET['page'] ?? 1;
 $i = ($page*$perPage)-$perPage;
 ?>
 <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td class="text-center"><?php echo e(++$i); ?></td>
    <td class="text-center"><?php echo e($user->name); ?></td>
    <td class="text-center"><?php echo e($user->email); ?></td>
    <td class="text-center">
        <?php echo e($user->mobile); ?>

    </td>
    <td class="text-center">
        <?php if($user->status == 0): ?>
       <a class="btn btn-warning text-center" href="<?php echo e(route('sellers_active',$user->id)); ?>"><?php echo e(trans("lang.deactive")); ?></a>
       <?php else: ?>
       <a class="btn btn-success text-center" href="<?php echo e(route('sellers_inactive',$user->id)); ?>"><?php echo e(trans("lang.active")); ?></a>
       <?php endif; ?>


    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($sellers->onEachSide(1)->links('vendor.pagination.default')); ?>






        </div>
      </div>
    </div>
</div>
      </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b2c_backend\resources\views/users/sellers_list.blade.php ENDPATH**/ ?>